
export enum Tool {
  MASK = 'MASK',
}

export interface HistoryStep {
  file: File;
  prompt: string;
}
